package course_api.springbootstarter.item;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class BusinessService
{
	@AutoWired
	private ItemRepository itemrepository;
	
	/*
	 * private List<Item> items = new ArrayList<>(Arrays.asList ( new
	 * Item("Item1","ABC","desc1",50), new Item("Item2","XYZ","desc2",100) ));
	 */
	
	public List<Item> getallitems() 
	{
		//return items.stream().sorted().collect(Collectors.toList());
		List <Item> items=new ArrayList<>();
		itemrepository.findAll()
		.forEach(items::add);
		return items.stream().sorted().collect(Collectors.toList());
		
	}
	public Item get_item(String id)
	{
		//return items.stream().filter(i->i.getId().equals(id)).findFirst().get();
		return itemrepository.findOne(id);
	}
	public void addItem(Item item) 
	{
		//items.add(item);
		itemrepository.save(item);
		
	}
	public void UpdateItem(Item item,String id) 
	{
		/*
		 * for(int i =0;i<items.size();i++) { Item t =items.get(i);
		 * if(t.getId().equalsIgnoreCase(id)) { items.set(i,item); return; } }
		 */
		itemrepository.save(item);

		
	}
	public void deleteItem(String id)
	{
		//items.removeIf(i->i.getId().equals(id))	;
		itemrepository.delete(id);

		
	}
}
