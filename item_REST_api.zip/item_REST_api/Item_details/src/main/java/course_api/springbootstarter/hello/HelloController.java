package course_api.springbootstarter.hello;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import course_api.springbootstarter.ItemApiApp;
import course_api.springbootstarter.item.Item;

@RestController
public class HelloController
{
	@RequestMapping("/hello")
	public String sayHi() 
	{
		return "Hi";
	}
}
