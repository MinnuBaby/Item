package course_api.springbootstarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemApiApp 
{
	public static void main(String[] args) 
	{
		SpringApplication.run(ItemApiApp.class, args);//create a servelet container and run it
	}
}
