package course_api.springbootstarter.item;

import org.springframework.data.repository.CrudRepository;
public interface ItemRepository extends CrudRepository<Item ,String>{

	//getAllItems
	//getItem(String id)
	//UpdateItem(Item t)
	//deleteItem(String id)
}
